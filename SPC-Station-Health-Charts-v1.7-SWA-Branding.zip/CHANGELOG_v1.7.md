# Changelog v1.7 (2025-10-09)

## Added
- Southwest Airlines branding applied to documentation and explainer.
- Distribution chart now follows phase slider; histogram auto-bins filtered X values.

## Changed
- Exported PNGs no longer include the bottom "Generated" footer strip.
- Documentation updated to reflect new behavior and branding.

## Fixed
- Minor UI/wording consistency across docs.


